# YouTube Transcript API (Flask)

Simple Flask API to fetch transcript of a YouTube video (if available).

## Run locally

```bash
pip install -r requirements.txt
python app.py
```

## API usage

`GET /transcript?video_id=VIDEO_ID`

### Example:

```
GET http://localhost:5000/transcript?video_id=dQw4w9WgXcQ
```

### Response:

```json
{
  "transcript": "Here is the transcript text..."
}
```

Deployable on Replit / Render / Vercel (with Python support).
